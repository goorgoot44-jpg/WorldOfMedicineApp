package com.worldofmedicine.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private static final String BASE_URL      = "https://world-of-medicine.netlify.app";
    private static final String URL_HOME      = BASE_URL + "/#home";
    private static final String URL_DOCTORS   = BASE_URL + "/#doctors";
    private static final String URL_AWARENESS = BASE_URL + "/#awareness-section";
    private static final String URL_NURSING   = BASE_URL + "/nurse-profile";
    private static final String URL_STORE     = BASE_URL + "/#store-section";

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private ProgressBar progressBar;
    private LinearLayout offlineLayout;
    private BottomNavigationView bottomNav;
    private int currentNavItem = R.id.nav_home;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView       = findViewById(R.id.web_view);
        swipeRefresh  = findViewById(R.id.swipe_refresh);
        progressBar   = findViewById(R.id.progress_bar);
        offlineLayout = findViewById(R.id.offline_layout);
        bottomNav     = findViewById(R.id.bottom_navigation);
        Button retryBtn = findViewById(R.id.btn_retry);

        setupWebView();

        swipeRefresh.setColorSchemeResources(
                R.color.primary_blue, R.color.accent_teal, R.color.primary_dark);
        swipeRefresh.setOnRefreshListener(() -> {
            if (isNetworkAvailable()) webView.reload();
            else { swipeRefresh.setRefreshing(false); showOfflinePage(); }
        });

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == currentNavItem) return true;
            currentNavItem = id;
            if (!isNetworkAvailable()) { showOfflinePage(); return true; }

            String url;
            if      (id == R.id.nav_home)      url = URL_HOME;
            else if (id == R.id.nav_doctors)   url = URL_DOCTORS;
            else if (id == R.id.nav_awareness) url = URL_AWARENESS;
            else if (id == R.id.nav_nursing)   url = URL_NURSING;
            else                               url = URL_STORE;
            loadUrl(url);
            return true;
        });

        retryBtn.setOnClickListener(v -> {
            if (isNetworkAvailable()) { hideOfflinePage(); loadUrl(BASE_URL); }
            else v.startAnimation(AnimationUtils.loadAnimation(this, R.anim.shake));
        });

        if (isNetworkAvailable()) loadUrl(BASE_URL);
        else showOfflinePage();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        CookieManager.getInstance().setAcceptCookie(true);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith(BASE_URL)) return false;
                if (url.startsWith("https://wa.me") || url.startsWith("https://api.whatsapp.com")
                        || url.startsWith("whatsapp://")) {
                    tryExternalIntent(Intent.ACTION_VIEW, url); return true;
                }
                if (url.startsWith("tel:"))    { tryExternalIntent(Intent.ACTION_DIAL,    url); return true; }
                if (url.startsWith("mailto:")) { tryExternalIntent(Intent.ACTION_SENDTO,  url); return true; }
                return true; // block all other external URLs
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progressBar.setVisibility(View.VISIBLE);
                progressBar.setProgress(0);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
                syncBottomNavWithUrl(url);
                injectMobileOptimizations(view);
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String desc, String failingUrl) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
                if (!isNetworkAvailable()) showOfflinePage();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int progress) {
                progressBar.setProgress(progress);
                if (progress == 100) progressBar.setVisibility(View.GONE);
            }
        });
    }

    private void tryExternalIntent(String action, String url) {
        try { startActivity(new Intent(action, Uri.parse(url))); } catch (Exception ignored) {}
    }

    private void loadUrl(String url) {
        hideOfflinePage();
        progressBar.setVisibility(View.VISIBLE);
        webView.loadUrl(url);
    }

    private void injectMobileOptimizations(WebView view) {
        String js = "(function(){" +
            "var m=document.querySelector('meta[name=viewport]');" +
            "if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}" +
            "m.content='width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no';" +
            "document.documentElement.style.scrollBehavior='smooth';" +
            "})();";
        view.evaluateJavascript(js, null);
    }

    private void syncBottomNavWithUrl(String url) {
        if (url == null) return;
        int id;
        if      (url.contains("/nurse-profile")) id = R.id.nav_nursing;
        else if (url.contains("#doctors"))       id = R.id.nav_doctors;
        else if (url.contains("#awareness"))     id = R.id.nav_awareness;
        else if (url.contains("#store"))         id = R.id.nav_store;
        else                                     id = R.id.nav_home;
        if (currentNavItem != id) { currentNavItem = id; bottomNav.setSelectedItemId(id); }
    }

    private void showOfflinePage() {
        webView.setVisibility(View.GONE);
        swipeRefresh.setVisibility(View.GONE);
        offlineLayout.setVisibility(View.VISIBLE);
        offlineLayout.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in));
    }

    private void hideOfflinePage() {
        offlineLayout.setVisibility(View.GONE);
        swipeRefresh.setVisibility(View.VISIBLE);
        webView.setVisibility(View.VISIBLE);
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            android.net.Network net = cm.getActiveNetwork();
            if (net == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(net);
            return caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                    || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                    || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
        } else {
            //noinspection deprecation
            android.net.NetworkInfo info = cm.getActiveNetworkInfo();
            return info != null && info.isConnected();
        }
    }

    @Override
    public void onBackPressed() {
        if (offlineLayout.getVisibility() == View.VISIBLE) { super.onBackPressed(); return; }
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onPause()   { super.onPause();   webView.onPause(); }
    @Override protected void onResume()  { super.onResume();  webView.onResume(); }

    @Override
    protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }
}
