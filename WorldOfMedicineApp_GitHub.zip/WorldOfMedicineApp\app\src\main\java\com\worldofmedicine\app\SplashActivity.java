package com.worldofmedicine.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    private static final long SPLASH_DURATION = 2800L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        ImageView logoImage = findViewById(R.id.splash_logo);
        TextView appNameAr = findViewById(R.id.splash_app_name_ar);
        TextView appNameEn = findViewById(R.id.splash_app_name_en);
        TextView tagline = findViewById(R.id.splash_tagline);
        View loadingBar = findViewById(R.id.splash_loading_bar);
        View loadingTrack = findViewById(R.id.splash_loading_track);

        // Initial state: invisible & scaled down
        logoImage.setAlpha(0f);
        logoImage.setScaleX(0.5f);
        logoImage.setScaleY(0.5f);
        appNameAr.setAlpha(0f);
        appNameAr.setTranslationY(40f);
        appNameEn.setAlpha(0f);
        appNameEn.setTranslationY(40f);
        tagline.setAlpha(0f);
        tagline.setTranslationY(30f);
        loadingTrack.setAlpha(0f);

        // Logo animation
        ObjectAnimator logoAlpha = ObjectAnimator.ofFloat(logoImage, "alpha", 0f, 1f);
        ObjectAnimator logoScaleX = ObjectAnimator.ofFloat(logoImage, "scaleX", 0.5f, 1f);
        ObjectAnimator logoScaleY = ObjectAnimator.ofFloat(logoImage, "scaleY", 0.5f, 1f);
        AnimatorSet logoAnim = new AnimatorSet();
        logoAnim.playTogether(logoAlpha, logoScaleX, logoScaleY);
        logoAnim.setDuration(700);
        logoAnim.setInterpolator(new DecelerateInterpolator(1.5f));

        // App name Arabic animation
        ObjectAnimator nameArAlpha = ObjectAnimator.ofFloat(appNameAr, "alpha", 0f, 1f);
        ObjectAnimator nameArTransY = ObjectAnimator.ofFloat(appNameAr, "translationY", 40f, 0f);
        AnimatorSet nameArAnim = new AnimatorSet();
        nameArAnim.playTogether(nameArAlpha, nameArTransY);
        nameArAnim.setDuration(500);
        nameArAnim.setStartDelay(600);
        nameArAnim.setInterpolator(new DecelerateInterpolator());

        // App name English animation
        ObjectAnimator nameEnAlpha = ObjectAnimator.ofFloat(appNameEn, "alpha", 0f, 1f);
        ObjectAnimator nameEnTransY = ObjectAnimator.ofFloat(appNameEn, "translationY", 40f, 0f);
        AnimatorSet nameEnAnim = new AnimatorSet();
        nameEnAnim.playTogether(nameEnAlpha, nameEnTransY);
        nameEnAnim.setDuration(500);
        nameEnAnim.setStartDelay(750);
        nameEnAnim.setInterpolator(new DecelerateInterpolator());

        // Tagline animation
        ObjectAnimator taglineAlpha = ObjectAnimator.ofFloat(tagline, "alpha", 0f, 1f);
        ObjectAnimator taglineTransY = ObjectAnimator.ofFloat(tagline, "translationY", 30f, 0f);
        AnimatorSet taglineAnim = new AnimatorSet();
        taglineAnim.playTogether(taglineAlpha, taglineTransY);
        taglineAnim.setDuration(500);
        taglineAnim.setStartDelay(950);
        taglineAnim.setInterpolator(new DecelerateInterpolator());

        // Loading track fade in
        ObjectAnimator trackAlpha = ObjectAnimator.ofFloat(loadingTrack, "alpha", 0f, 1f);
        trackAlpha.setDuration(400);
        trackAlpha.setStartDelay(1100);

        // Loading bar progress animation
        ObjectAnimator barScaleX = ObjectAnimator.ofFloat(loadingBar, "scaleX", 0f, 1f);
        barScaleX.setDuration(1500);
        barScaleX.setStartDelay(1200);
        barScaleX.setInterpolator(new AccelerateDecelerateInterpolator());

        // Play all together
        AnimatorSet masterSet = new AnimatorSet();
        masterSet.playTogether(logoAnim, nameArAnim, nameEnAnim, taglineAnim, trackAlpha, barScaleX);
        masterSet.start();

        // Navigate to main after splash duration
        logoImage.postDelayed(() -> {
            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, SPLASH_DURATION);
    }
}
