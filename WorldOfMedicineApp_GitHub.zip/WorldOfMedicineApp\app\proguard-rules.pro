# ProGuard rules for World of Medicine
# Keep WebView JavaScript interfaces
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep all activities
-keep public class * extends android.app.Activity

# Material Components
-keep class com.google.android.material.** { *; }

# AndroidX
-keep class androidx.** { *; }

# Keep application class
-keep class com.worldofmedicine.app.** { *; }
